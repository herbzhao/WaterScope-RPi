#ifndef LCD16x2_H
#define LCD16x2_H


#include "wirish.h"

#define SET_TRIS    0x01
#define SET_LAT     0x02
#define GET_PORT    0x03
#define GET_BUT     0x05
#define GET_ID      0x20
#define GET_FRM     0x21
#define LCD_CLR     0x60
#define LCD_WR      0x61
#define SET_BL		0x62
#define UART_EN     0x10

#define BOARD_ID    0x65
#define ADDRESS     0x30

#define	DELAY_TIME	10

typedef	unsigned char uint8_t;

/**
 * @author      Stefan Mavrodiev @ OLIMEX LTD <support@olimex.com>
 * library modified for Olimexino-STM32 and Maple IDE 0.12 by Stanimir Petev
 * @since       2015-04-29
 */
class LCD16x2{
	private:
		uint8_t pinSDA, pinSCL, SL_READ, SL_WRITE, X, Y;
		const static char  ACK = 0;
		const static char NACK = 1;
		const static uint8_t RW_MASK  = 0x80;

    public:
        
        LCD16x2 (uint8_t Address, uint8_t nSDA, uint8_t nSCL);
        ~LCD16x2();

		void SDA_OUT();
		void SDA_IN();
		void SCL_OUT();
		void SCL_IN();
		
		void Start();
		void Stop();
		void WaitMicrosecond(int x);
		char WriteSingle( char data );
		char ReadSingle( char ack );
		uint8_t getSDAnum();
		uint8_t getSCLnum();
        
        uint8_t getID();
        uint8_t getFirmwareVersion();
        
        void uartEnable(bool state);
        
        void I2C_pinMode(uint8_t pin, uint8_t direction);
        void I2C_digitalWrite(uint8_t pin, uint8_t level);
        uint8_t I2C_digitalRead(uint8_t pin);
        uint8_t readButtons();    
        
		void lcdSetBacklight(uint8_t value);
        void lcdClear();
        void lcdGoToXY(uint8_t x, uint8_t y);
        void lcdWrite(char *string); 
};
#endif
