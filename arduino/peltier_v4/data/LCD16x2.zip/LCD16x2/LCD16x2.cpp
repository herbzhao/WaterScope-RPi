/*
 * LCD16x2.cpp
 * 
 * Copyright 2013 OLIMEX LTD <support@olimex.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 * MA 02110-1301, USA.
 */


#include "wirish.h"
#include "LCD16x2.h"

LCD16x2::LCD16x2 (uint8_t Address, uint8_t nSDA, uint8_t nSCL)
{
    X = 0;
    Y = 1;

	SL_READ  = (Address<<1) | 1;
	SL_WRITE = (Address<<1) | 0;
	pinSDA = nSDA;
	pinSCL = nSCL;
	digitalWrite (pinSDA, LOW);
	digitalWrite (pinSCL, LOW);
	SCL_OUT();
	SDA_OUT();
}

LCD16x2::~LCD16x2 ()
{
}

void LCD16x2::SDA_OUT()
{
	pinMode(pinSDA, OUTPUT);
}

void LCD16x2::SDA_IN()
{
	pinMode(pinSDA,  INPUT);
}

void LCD16x2::SCL_OUT()
{
	pinMode(pinSCL, OUTPUT);
}

void LCD16x2::SCL_IN()
{
	pinMode(pinSCL, INPUT);
} 

void LCD16x2::Start()
{
	SDA_OUT();
	WaitMicrosecond(DELAY_TIME);
	SCL_OUT();
	WaitMicrosecond(DELAY_TIME);		
}

void LCD16x2::Stop()
{
	SDA_OUT();
	WaitMicrosecond(DELAY_TIME);
	SCL_IN();
	WaitMicrosecond(DELAY_TIME);
	SDA_IN();
	WaitMicrosecond(DELAY_TIME);
}

	
void LCD16x2::WaitMicrosecond(int x)
{
	delayMicroseconds(x);
}
char LCD16x2::WriteSingle( char data )
{
	char i;

	// Send the 8 bits
	for(i = 0; i<8; i++)
	{
		WaitMicrosecond(DELAY_TIME);
		if(data&RW_MASK)
			SDA_IN();
		else
			SDA_OUT();
		data <<= 1;
		WaitMicrosecond(DELAY_TIME);
		SCL_IN();
		WaitMicrosecond(DELAY_TIME);
		SCL_OUT();
	}

	// Read the ACK
	WaitMicrosecond(DELAY_TIME);
	SDA_IN();
	WaitMicrosecond(DELAY_TIME);
	SCL_IN();
	WaitMicrosecond(DELAY_TIME);
	i = digitalRead(pinSDA);
	SCL_OUT();
	WaitMicrosecond(DELAY_TIME);

	return i;		
}
	
char LCD16x2::ReadSingle( char ack )
{
	char data = 0, i;

	SDA_IN();		
	for(i = 0; i < 8; i++)
	{
		WaitMicrosecond(DELAY_TIME);
		SCL_IN();
		while(digitalRead(pinSCL)==0);
		WaitMicrosecond(DELAY_TIME);
		data |= digitalRead(pinSDA);
		if( i!=7 )
			data<<=1;
		WaitMicrosecond(DELAY_TIME);
		SCL_OUT();
		WaitMicrosecond(DELAY_TIME);
	}

	// send the ACK/NACK
	WaitMicrosecond(DELAY_TIME);
	if(ack)
		SDA_IN();
	else
		SDA_OUT();
	WaitMicrosecond(DELAY_TIME);
	SCL_IN();
	WaitMicrosecond(DELAY_TIME);
	SCL_OUT();
	WaitMicrosecond(DELAY_TIME);

	return data;		
}


uint8_t LCD16x2::getSDAnum()
{
	return pinSDA;
}

uint8_t LCD16x2::getSCLnum()
{
	return pinSCL;
}


/**
 * Read the id of the shield.
 * @return      If read value match BOARD_ID(0x65) the method return 1,
 * otherwise - 0.
 */
uint8_t LCD16x2::getID(){
    uint8_t id = 0;
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(GET_ID);
    Stop();

	Start();
	WriteSingle(SL_READ);
	id = ReadSingle(NACK);
	Stop();
    return id;
}

void LCD16x2::lcdSetBacklight(uint8_t value){
	Start();
	WriteSingle(SL_WRITE);
	WriteSingle(SET_BL);
	WriteSingle(value);
	Stop();
}
void LCD16x2::uartEnable(bool state){
    uint8_t en;
    if(state == true)
        en = 0x01;
    else
        en = 0x00;
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(UART_EN);
    WriteSingle(en);
    Stop();
}
uint8_t LCD16x2::getFirmwareVersion(){
    uint8_t firm = 0;
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(GET_FRM);
    Stop();
	
	Start();
	WriteSingle(SL_READ);
	firm = ReadSingle(NACK);
	Stop();
    return firm;
}
/**
 * Set direction of GPIO.
 * @param pin   The pin number according to schematic: GPIO1, GPIO2, etc...
 * @param direction     The direction of the GPIO: OUTPUT or INPUT.
 */
void LCD16x2::I2C_pinMode(uint8_t pin, uint8_t direction){
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(SET_TRIS);
    WriteSingle(pin);
    WriteSingle(!direction);
    Stop();
}

/**
 * If pin is set as output this method define the level of the GPIO.
 * If pin is input - it enables internal pull-up resistor (only available
 * for PORTB pins).
 * @param pin   The number of the desired GPIO: GPIO1, GPIO2, etc...
 * @param level The output level: HIGH or LOW
 */
void LCD16x2::I2C_digitalWrite(uint8_t pin, uint8_t level){
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(SET_LAT);
    WriteSingle(pin);
    WriteSingle(level);
    Stop();
}

/**
 * Read the state of individual GPIO, if configured as input.
 * @param pin   The number of the GPIO: GPIO1, GPIO2, etc...
 * @return      If input level is high - 1, else - 0.
 */
uint8_t LCD16x2::I2C_digitalRead(uint8_t pin){
    uint8_t port=0;
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(GET_PORT);
    WriteSingle(pin);
    Stop();
	
	Start();
	WriteSingle(SL_READ);
	port = ReadSingle(NACK);
	Stop();
    return port;
}

/**
 * Read the state of the 4 buttons.
 * @return      Bitmask with the 4 values: LSB - BUT1, MSB - BUT4
 */
uint8_t LCD16x2::readButtons(){
    uint8_t buttons=0;
    
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(GET_BUT);
    Stop();
	
	Start();
	WriteSingle(SL_READ);
	buttons = ReadSingle(NACK);
	Stop();
    return buttons;
}

/**
 * Clear the LCD screen.
 */
void LCD16x2::lcdClear(){
    Start();
	WriteSingle(SL_WRITE);
    WriteSingle(LCD_CLR);
    Stop();
    delay(100);
}

/**
 * Position the cursor of the LCD to a given X and Y coordinates.
 * @param x     X coordinate
 * @param y     Y coordinate
 */
void LCD16x2::lcdGoToXY(uint8_t x, uint8_t y){
    if(x > 16 || x < 1)
        return;
    else
        X = x - 1;
        
    if(y > 2)
        return;
    Y = y;
}

/**
 * Write string to the LCD screen.
 * @param string        String to be written.
 */
void LCD16x2::lcdWrite(char* string){
    uint8_t x, y;
    x = X;
    y = Y;
    
    for(int i = 0; string[i]; i++){
        Start();
		WriteSingle(SL_WRITE);
        WriteSingle(LCD_WR);
        WriteSingle(y);
        WriteSingle(x);
        WriteSingle(string[i]);
        Stop();
        
        x++;  
        if(x > 15){
            x = 0;
            y++;
            if(y > 2)
                return;
        }
        delay(20);      
    }
}
