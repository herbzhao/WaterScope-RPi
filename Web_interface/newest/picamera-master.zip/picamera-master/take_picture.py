#!/usr/bin/python3
import picamera
camera = picamera.PiCamera()
camera.capture('image.jpg')
